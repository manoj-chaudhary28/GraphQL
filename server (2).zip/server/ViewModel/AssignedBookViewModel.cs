using System;
using System.Collections.Generic;
using server.Models;

namespace server.ViewModel
{
    public partial class AssignedBookViewModel
    {
         public string StudentName{get;set;}
         public string BookName{get;set;}
         public string AssignedDate{get;set;}
         public string ReturnDate{get;set;}
         public string Status{get;set;}
    }
}
