
using System.Collections.Generic;
using System.Threading.Tasks;
using server.Models;

namespace server.Repository.IRepository
{
    public interface IBookRepository
    {   
        Task<Books> Get(int id);
        Task<List<Books>> All();
        Task<Books> Add(Books book);
         Task<List<Books>> Delete(int id);
    }
 
}