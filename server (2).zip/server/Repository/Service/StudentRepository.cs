
 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using server.Contaxt;
using server.Models;
using server.Repository.IRepository;

namespace server.Repository.Service
{
    public class StudentRepository : IStudentRepository
    {
        private readonly GraphQLContext _db;

        public StudentRepository(GraphQLContext db)
        {
            _db = db;
        }
        public async Task<Students> Get(int id)
        {
            return await _db.Students.FirstOrDefaultAsync(p => p.StudentId == id);
        }

        public async Task<List<Students>> All()
        { 
            return await _db.Students.ToListAsync();
        }

        public async Task<Students> Add(Students student)
        {
            student.CreateDate=DateTime.UtcNow;
            await _db.Students.AddAsync(student);
            await _db.SaveChangesAsync();
            return student;
        }

        
    }
}
