 
using GraphQL.Types;
 
namespace server.FieldsType
{
    public class StudentFieldsType : InputObjectGraphType
    {
        public StudentFieldsType()
        {
           Name="StudentInput";
          
            Field<IntGraphType>("studentId");
            Field<StringGraphType>("firstName");
            Field<StringGraphType>("lastName");
            // Field<StringGraphType>("gender");
            Field<StringGraphType>("mobileNumber");
            Field<StringGraphType>("emailAddress");
            Field<StringGraphType>("addressLine1");
            Field<StringGraphType>("addressLine2");
            Field<StringGraphType>("city");
            Field<StringGraphType>("state");
            Field<StringGraphType>("postalCode");
          
             
        }
    }
}
