 
using GraphQL.Types;
 
namespace server.FieldsType
{
    public class StudentAssignedBookFieldsType : InputObjectGraphType
    {
        public StudentAssignedBookFieldsType()
        {
           Name="StudentAssignedBookInput";
            Field<IntGraphType>("assignedId");
            Field<StringGraphType>("bookId");
            Field<StringGraphType>("studentId");
            Field<StringGraphType>("assignedDate");
            Field<StringGraphType>("returnDate");
            Field<StringGraphType>("status");
            
        }
    }
}
