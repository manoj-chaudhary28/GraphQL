 

using GraphQL.Types;
using server.FieldsType;
using server.Models;
using server.ViewModel;

namespace server.Fields
{
   public class StudentBookViewModelFields : ObjectGraphType<StudentBookViewModel>
    {
        public StudentBookViewModelFields()
        {
            Field(x => x.Students,true,typeof(ListGraphType<StudentFields>));
            Field(x => x.Books,true,typeof(ListGraphType<BookFields>));
        }
    }
}
