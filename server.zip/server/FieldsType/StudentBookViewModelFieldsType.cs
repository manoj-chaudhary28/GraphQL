 
using GraphQL.Types;
 
namespace server.FieldsType
{
    public class StudentBookViewModelFieldsType : InputObjectGraphType
    {
        public StudentBookViewModelFieldsType()
        {
            Name="StudentBookViewModelInput";
            Field<ListGraphType>("students");
            Field<ListGraphType>("books");
            
             
        }
    }
}
