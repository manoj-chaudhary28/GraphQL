 

using GraphQL.Types;
using server.Models;
namespace server.Fields
{
   public class StudentFields : ObjectGraphType<Students>
    {
        public StudentFields()
        {
            Field(x => x.StudentId);
            Field(x => x.FirstName);
            Field(x => x.LastName);
            Field(x => x.Gender);
            Field(x => x.MobileNumber);
            Field(x => x.EmailAddress);
            Field(x => x.AddressLine1);
            Field(x => x.AddressLine2,nullable:true);
            Field(x => x.City);
            Field(x => x.State);
            Field(x => x.PostalCode);
             
        }
    }
}
