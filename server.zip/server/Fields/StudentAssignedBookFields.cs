 

using GraphQL.Types;
using server.Models;
namespace server.Fields
{
   public class StudentAssignedBookFields : ObjectGraphType<StudentAssignedBook>
    {
        public StudentAssignedBookFields()
        {
            Field(x => x.BookId);
            Field(x => x.BookId);
            Field(x => x.StudentId);
            Field(x => x.AssignedDate);
            Field(x => x.ReturnDate);
            Field(x => x.Status);
            
        }
    }
}
