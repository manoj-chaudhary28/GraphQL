 

using GraphQL.Types;
using server.Models;
using server.ViewModel;

namespace server.Fields
{
   public class StudentBookViewModelFields : ObjectGraphType<StudentBookViewModel>
    {
        public StudentBookViewModelFields()
        {
            Field(x => x.Students);
            Field(x => x.Books);
        }
    }
}
