 

using GraphQL.Types;
using server.FieldsType;
using server.Models;
using server.ViewModel;

namespace server.Fields
{
   public class AssignedBookViewModelFields : ObjectGraphType<AssignedBookViewModel>
    {
        public AssignedBookViewModelFields()
        {
            Field(x => x.StudentName);
            Field(x => x.BookName);
            Field(x => x.AssignedDate);
            Field(x => x.ReturnDate);
            Field(x => x.Status);
        }
    }
}
