 

using GraphQL.Types;
using server.Models;
namespace server.Fields
{
   public class BookFields : ObjectGraphType<Books>
    {
        public BookFields()
        {
            Field(x => x.BookId);
            Field(x => x.BookName);
            Field(x => x.Language);
            Field(x => x.Author);
            Field(x => x.Description);
            
        }
    }
}
