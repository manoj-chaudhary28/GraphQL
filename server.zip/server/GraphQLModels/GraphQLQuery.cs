
using GraphQL.Types;
using server.Fields;
using server.Repository;
using server.Repository.IRepository;

namespace server.GraphQLModels
{
    public class GraphQLQuery : ObjectGraphType
    {
        public GraphQLQuery(IStudentRepository studentRepository,IBookRepository bookRepository,IStudentAssignBookRepository studentAssignBookRepository)
        {
            Field<ListGraphType<StudentFields>>(
                "student",
                resolve: context => studentRepository.All());

            Field<ListGraphType<BookFields>>(
                "book",
                resolve: context => bookRepository.All());

            Field<ListGraphType<StudentBookViewModelFields>>(
                "bookandstudent",
                resolve: context => studentAssignBookRepository.GetStudentBook());

            Field<ListGraphType<AssignedBookViewModelFields>>(
                "assignedbooklist",
                resolve: context => studentAssignBookRepository.All());    
        }
    }
}


 