
using GraphQL.Types;
using server.Fields;
using server.Repository;
using server.Repository.IRepository;

namespace server.GrapjQLModels
{
    public class GraphQLQuery : ObjectGraphType
    {
        public GraphQLQuery(IStudentRepository studentRepository)
        {
            Field<ListGraphType<StudentFields>>(
                "student",
                resolve: context => studentRepository.All());
        }
    }
}


 