 

using GraphQL.Types;
using server.Fields;
using server.FieldsType;
using server.Models;
using server.Repository;
using server.Repository.IRepository;

namespace server.GrapjQLModels
{
    public class GraphQLMutation : ObjectGraphType
    {
        public GraphQLMutation(IStudentRepository studentRepository)
        {
            Name = "Mutation";
            Field<StudentFields>(
                "createStudent",
                arguments: new QueryArguments(
                    new QueryArgument<NonNullGraphType<StudentFieldsType>> { Name = "student" }
                ),
                resolve: context =>
                {
                    var student = context.GetArgument<Students>("student");
                    return studentRepository.Add(student);
                });
        }
    }
}
