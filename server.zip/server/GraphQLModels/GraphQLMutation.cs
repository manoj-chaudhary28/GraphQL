 

using GraphQL.Types;
using server.Fields;
using server.FieldsType;
using server.Models;
using server.Repository;
using server.Repository.IRepository;
using server.ViewModel;

namespace server.GraphQLModels
{
    public class GraphQLMutation : ObjectGraphType
    {
        public GraphQLMutation(IStudentRepository studentRepository,IBookRepository bookRepository,IStudentAssignBookRepository studentAssignBookRepository)
        {
            Name = "Mutation";
            Field<StudentFields>(
                "createStudent",
                arguments: new QueryArguments(
                    new QueryArgument<NonNullGraphType<StudentFieldsType>> { Name = "student" }
                ),
                resolve: context =>
                {
                    var student = context.GetArgument<Students>("student");
                    return studentRepository.Add(student);
                });

                 Field<BookFields>(
                "createBook",
                arguments: new QueryArguments(
                    new QueryArgument<NonNullGraphType<BookFieldsType>> { Name = "book" }
                ),
                resolve: context =>
                {
                    var book = context.GetArgument<Books>("book");
                    return bookRepository.Add(book);
                });

                //   Field<StudentBookViewModelFields>(
                // "getStudentBook",
                // arguments: new QueryArguments(
                //     new QueryArgument<NonNullGraphType<StudentBookViewModelFieldsType>> { Name = "studentandbook" }
                // ),
                // resolve: context =>
                // {
                //     StudentBookViewModel _viewModel= new StudentBookViewModel();
                //   _viewModel=  studentAssignBookRepository.GetStudentBook();
                //   return  _viewModel;
                // });
        }
    }
}
