using System;
using System.Collections.Generic;
using server.Models;

namespace server.ViewModel
{
    public partial class StudentBookViewModel
    {
         public List<Books>Books{get;set;}
         public List<Students>Students{get;set;}
    }
}
