
using System.Collections.Generic;
using System.Threading.Tasks;
using server.Models;

namespace server.Repository.IRepository
{
    public interface IStudentRepository
    {   
        Task<Students> Get(int id);
        Task<List<Students>> All();
        Task<Students> Add(Students student);
        Task<List<Students>> Delete(int id);
    }
 
}