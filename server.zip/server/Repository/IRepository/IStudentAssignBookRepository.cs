
using System.Collections.Generic;
using System.Threading.Tasks;
using server.Models;
using server.ViewModel;

namespace server.Repository.IRepository
{
    public interface IStudentAssignBookRepository
    {   
        Task<StudentAssignedBook> Get(int id);
        List<AssignedBookViewModel> All();
        Task<StudentAssignedBook> Add(StudentAssignedBook assignedBook);
        StudentBookViewModel GetStudentBook();
    }
 
}