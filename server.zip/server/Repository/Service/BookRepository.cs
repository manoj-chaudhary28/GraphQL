
 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using server.Contaxt;
using server.Models;
using server.Repository.IRepository;

namespace server.Repository.Service
{
    public class BookRepository : IBookRepository
    {
        private readonly GraphQLContext _db;

        public BookRepository(GraphQLContext db)
        {
            _db = db;
        }
        public async Task<Books> Get(int id)
        {
            return await _db.Books.FirstOrDefaultAsync(p => p.BookId == id);
        }

        public async Task<List<Books>> All()
        { 
            return await _db.Books.ToListAsync();
        }

        public async Task<Books> Add(Books book)
        {

            if(book.BookId > 0)
            {
                Books booksObject=await _db.Books.FirstOrDefaultAsync(p => p.BookId==book.BookId);
                book.CreateDate=booksObject.CreateDate;
                _db.Entry(booksObject).CurrentValues.SetValues(book);
                await _db.SaveChangesAsync();
            }
            else
            {
                  book.CreateDate=DateTime.UtcNow;
                  await _db.Books.AddAsync(book);
                  await _db.SaveChangesAsync();
            }

          
            return book;
        }

         public async Task<List<Books>> Delete(int id)
        {
             Books booksObject=await _db.Books.FirstOrDefaultAsync(p => p.BookId==id);
            if (booksObject != null) {
                    _db.Books.Remove(booksObject);
                    await _db.SaveChangesAsync();
            }
            return  await _db.Books.ToListAsync();
        }
    }
}
