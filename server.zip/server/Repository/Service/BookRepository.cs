
 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using server.Context;
using server.Models;
using server.Repository.IRepository;

namespace server.Repository.Service
{
    public class BookRepository : IBookRepository
    {
        private readonly GraphQLContext _db;

        public BookRepository(GraphQLContext db)
        {
            _db = db;
        }
        public async Task<Books> Get(int id)
        {
            return await _db.Books.FirstOrDefaultAsync(p => p.BookId == id);
        }

        public async Task<List<Books>> All()
        { 
            return await _db.Books.ToListAsync();
        }

        public async Task<Books> Add(Books book)
        {
            book.CreateDate=DateTime.UtcNow;
            await _db.Books.AddAsync(book);
            await _db.SaveChangesAsync();
            return book;
        }

        
    }
}
