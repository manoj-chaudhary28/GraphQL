
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using server.Contaxt;
using server.Models;
using server.Repository.IRepository;
using server.ViewModel;

namespace server.Repository.Service
{
    public class StudentAssignBookRepository : IStudentAssignBookRepository
    {
        private readonly GraphQLContext _db;

        public StudentAssignBookRepository(GraphQLContext db)
        {
            _db = db;
        }
        public async Task<StudentAssignedBook> Get(int id)
        {
            return await _db.StudentAssignedBook.FirstOrDefaultAsync(p => p.BookId == id);
        }

        public async Task<List<StudentAssignedBook>> All()
        { 
            return await _db.StudentAssignedBook.ToListAsync();
        }

        public async Task<StudentAssignedBook> Add(StudentAssignedBook book)
        {
            book.CreateDate=DateTime.UtcNow;
            await _db.StudentAssignedBook.AddAsync(book);
            await _db.SaveChangesAsync();
            return book;
        }

         public StudentBookViewModel GetStudentBook()
        {
            StudentBookViewModel _viewModel= new StudentBookViewModel();
            _viewModel.Books=_db.Books.ToList();
             _viewModel.Students=_db.Students.ToList();
             return  _viewModel;
        }
        
    }
}
