﻿using System;
using System.Collections.Generic;

namespace server.Models
{
    public partial class StudentAssignedBook
    {
        public long AssignedId { get; set; }
        public long? StudentId { get; set; }
        public long? BookId { get; set; }
        public DateTime? AssignedDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public string Status { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
