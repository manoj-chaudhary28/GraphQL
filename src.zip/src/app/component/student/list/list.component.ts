import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';

const fetchStudent = gql`
query student{student {studentId firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}`;
const deleteStudent = gql`
mutation ($studentId:Int!)
{deleteStudent(studentId:$studentId)
  {studentId firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}
`;
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
public studentData:any;
  constructor(private apollo:Apollo) {}
  ngOnInit() {this.fetchstudents()}
  fetchstudents(){
    this.apollo.query<any>({
      query: fetchStudent,
      variables: {
        student:{
        }
      }
    })
    .subscribe(({data}) => {
      this.studentData=data.student;
    }
    , (error) => {
      console.log('there was an error sending the query', error);
    });
  }

  onDelete(Id:string)
  {
    if (confirm("Are you sure you want to delete this ?")) { 
    this.apollo.mutate<any>({
      mutation: deleteStudent,
      variables: {
        studentId:Id
    }
    }).subscribe(({ data }) => {
      this.studentData=data.deleteStudent;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }}
  
}
