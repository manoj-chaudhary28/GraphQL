import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';

const fetchStudent = gql`
query student{student {firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}`;

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
public studentData:any;
  constructor(private apollo:Apollo) {}
  ngOnInit() {this.fetchstudents()}
  fetchstudents(){
    this.apollo.query({
      query: fetchStudent,
      variables: {
        student:{
        }
      }
    }).subscribe(({data}) => {
      this.studentData=data;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
}
