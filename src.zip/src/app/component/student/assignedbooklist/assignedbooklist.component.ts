import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';

const fetchAssignedBook = gql`
query assignedbooklist{assignedbooklist {studentName bookName assignedDate returnDate status}}`;

@Component({
  selector: 'app-assignedbooklist',
  templateUrl: './assignedbooklist.component.html',
  styleUrls: ['./assignedbooklist.component.css']
})
export class AssignedbooklistComponent implements OnInit {
  public bookList:any;
  constructor(private apollo:Apollo) {}

  ngOnInit() {this.fetchassignedbooklist();}
  fetchassignedbooklist(){
    this.apollo.query({
      query: fetchAssignedBook,
      variables: {
        assignedbooklist:{
        }
      }
    }).subscribe(({data}) => {
      this.bookList=data;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
}
