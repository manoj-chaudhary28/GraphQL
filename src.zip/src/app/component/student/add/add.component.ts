import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';

const submitStudent = gql`
mutation ($student:StudentInput!){createStudent(student:$student){firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}`;
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  model: any = {};
   
  constructor(private apollo:Apollo) { }
  ngOnInit() {
  
  }
  save(){

    this.apollo.mutate({
      mutation: submitStudent,
      variables: {
        student:{
        firstName: this.model.firstName,
        lastName: this.model.lastName,
        emailAddress:this.model.emailAddress,
        mobileNumber:this.model.mobileNumber,
        addressLine1:this.model.addressLine1,
        addressLine2:this.model.addressLine2,
        city:this.model.city,
        state:this.model.state,
        postalCode:this.model.postalCode
      }
    }
    }).subscribe(({ data }) => {
      console.log('got data', data);
       
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

}


