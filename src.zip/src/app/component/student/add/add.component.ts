import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';
import { Router, ActivatedRoute } from '@angular/router';
import { $ } from 'protractor';

const submitStudent = gql`
mutation ($student:StudentInput!)
{createStudent(student:$student)
{studentId firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}
`;

const getStudent = gql`
mutation ($studentId:Int!)
{getStudentById(studentId:$studentId)
{studentId firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}
`;


@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  model: any = {};
 
  constructor(private apollo:Apollo,private router: Router,private queryRoute: ActivatedRoute) { }

 
  ngOnInit() {
 
    if(this.queryRoute.snapshot.params["id"])
   {
    var studentId=this.queryRoute.snapshot.params["id"];
    this.onGetById(studentId);
   }
  }
  onGetById(Id:string)
  {
    this.apollo.mutate({
      mutation: getStudent,
      variables: {
        studentId:Id
    }
    }).subscribe(({ data }) => {
        
        this.model.studentId=data.getStudentById["studentId"];
        this.model.firstName=data.getStudentById["firstName"];
        this.model.lastName=data.getStudentById["lastName"];
        this.model.emailAddress=data.getStudentById["emailAddress"];
        this.model.mobileNumber=data.getStudentById["mobileNumber"];
        this.model.addressLine1=data.getStudentById["addressLine1"];
        this.model.addressLine2=data.getStudentById["addressLine2"];
        this.model.city=data.getStudentById["city"];
        this.model.state=data.getStudentById["state"];
        this.model.postalCode=data.getStudentById["postalCode"];
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

  save(){
    this.apollo.mutate({
      mutation: submitStudent,
      variables: {
        student:{
        studentId: this.model.studentId==undefined?0:this.model.studentId,
        firstName: this.model.firstName,
        lastName: this.model.lastName,
        emailAddress:this.model.emailAddress,
        mobileNumber:this.model.mobileNumber,
        addressLine1:this.model.addressLine1,
        addressLine2:this.model.addressLine2,
        city:this.model.city,
        state:this.model.state,
        postalCode:this.model.postalCode
      }
    }
    }).subscribe(({data}) => {
      this.router.navigate(['/list-student']);
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

  

}


