import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';
import { Router } from '@angular/router';

const fetchStudentBook = gql`
query bookandstudent{student{firstName,lastName,studentId},book{bookName,bookId}}
`;

const assignBookToStudent = gql`
mutation ($studentassignedbook:StudentAssignedBookInput!)
{assignBookToStudent(studentassignedbook:$studentassignedbook)
{bookId studentId assignedDate returnDate status}}
`;


@Component({
  selector: 'app-assignbook',
  templateUrl: './assignbook.component.html',
  styleUrls: ['./assignbook.component.css']
})
export class AssignbookComponent implements OnInit {
  // model: any = {};
  public studentBook:any;
   bookId="0";
   studentId ="0";
   assignDate=null;
   returnDate =null;
   status =null;
  constructor(private apollo:Apollo,private router: Router) { }

  ngOnInit() { this.fetch()}

  fetch()
  {
    this.apollo.query({
      query: fetchStudentBook,
      variables: {
        bookandstudent:{}
    }
    }).subscribe(({ data }) => {
      this.studentBook=data;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
  
  save(){
    debugger;
    var assignedDate=this.assignDate;
    this.apollo.mutate({
      mutation: assignBookToStudent,
      variables: {
        studentassignedbook:{
          studentId: this.studentId,
          bookId: this.bookId,
          assignedDate:this.assignDate,
          returnDate:this.returnDate,
          status:this.status
      }
    }

    }).subscribe(({ data }) => {
      this.router.navigate(['/list-student']);
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

}
