import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';
import { Router } from '@angular/router';

const fetchStudentBook = gql`
query bookandstudent{student{firstName,lastName,studentId},book{bookName,bookId}}
`;

const assignBookToStudent = gql`
mutation ($student:StudentInput!)
{createStudent(student:$student)
{firstName lastName emailAddress mobileNumber addressLine1 addressLine2 city state postalCode}}
`;


@Component({
  selector: 'app-assignbook',
  templateUrl: './assignbook.component.html',
  styleUrls: ['./assignbook.component.css']
})
export class AssignbookComponent implements OnInit {
  model: any = {};
  public studentBook:any;
  constructor(private apollo:Apollo,private router: Router) { }

  ngOnInit() { this.fetch()}

  fetch()
  {
    this.apollo.query({
      query: fetchStudentBook,
      variables: {
        bookandstudent:{}
    }
    }).subscribe(({ data }) => {
      this.studentBook=data;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
  
  save(){
    debugger;
    this.apollo.mutate({
      mutation: assignBookToStudent,
      variables: {
        assignbookstudent:{
        studentId: this.model.studentId,
        bookId: this.model.bookId,
        assignDate:this.model.assignDate,
        returnDate:this.model.returnDate,
        status:this.model.status
      }
    }
    }).subscribe(({ data }) => {
      this.router.navigate(['/list-student']);
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

}
