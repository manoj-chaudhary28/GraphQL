import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';
import { Router } from '@angular/router';

const submitBook = gql`
mutation ($book:BookInput!){createBook(book:$book){bookName language author description}}`;

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {

  model: any = {};
   
  constructor(private apollo:Apollo, private router: Router) { }
  ngOnInit() {
  
  }
  save(){

    this.apollo.mutate({
      mutation: submitBook,
      variables: {
        book:{
          bookName: this.model.bookName,
          language: this.model.language,
          author:this.model.author,
          description:this.model.description,
      }
    }
    }).subscribe(({ data }) => {
    
      this.router.navigate(['/list-book']);
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

}
