import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';

const fetchBook = gql`
query book{book {bookId bookName language author description}}`;

const deleteBook = gql`
mutation ($bookId:Int!)
{deleteBook(bookId:$bookId)
  {bookId bookName language author description}}
`;

@Component({
  selector: 'app-listbook',
  templateUrl: './listbook.component.html',
  styleUrls: ['./listbook.component.css']
})
export class ListbookComponent implements OnInit {

  public bookData:any;
  constructor(private apollo:Apollo) {}
  
  ngOnInit() {this.fetchbooks()}

  fetchbooks(){
    this.apollo.query<any>({
      query: fetchBook,
      variables: {
        book:{
        }
      }
    }).subscribe(({data}) => {
      this.bookData=data.book;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

  onDelete(Id:string)
  {
    if (confirm("Are you sure you want to delete this ?")) { 
    this.apollo.mutate<any>({
      mutation: deleteBook,
      variables: {
        bookId:Id
    }
    }).subscribe(({ data }) => {
      debugger;
      this.bookData=data.deleteBook;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }}
}
