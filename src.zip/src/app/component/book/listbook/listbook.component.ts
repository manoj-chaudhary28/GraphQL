import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';

const fetchBook = gql`
query book{book {bookName language author description}}`;


@Component({
  selector: 'app-listbook',
  templateUrl: './listbook.component.html',
  styleUrls: ['./listbook.component.css']
})
export class ListbookComponent implements OnInit {

  public bookData:any;
  constructor(private apollo:Apollo) {}
  
  ngOnInit() {this.fetchbooks()}

  fetchbooks(){
    this.apollo.query({
      query: fetchBook,
      variables: {
        book:{
        }
      }
    }).subscribe(({data}) => {
      this.bookData=data;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
}
