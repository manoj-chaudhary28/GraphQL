import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
 import { AddbookComponent } from './component/book/addbook/addbook.component';
import { ListbookComponent } from './component/book/listbook/listbook.component';

import { AddComponent } from './component/student/add/add.component';
import { ListComponent } from './component/student/list/list.component';
const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'add-student', component: AddComponent},
  {path: 'list-student', component: ListComponent},
  {path: 'add-book', component: AddbookComponent},
  {path: 'list-book', component: ListbookComponent},
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
