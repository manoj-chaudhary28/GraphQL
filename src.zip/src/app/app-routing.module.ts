import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
// import { AddComponent } from './component/book/add/add.component';
// import { ListComponent } from './component/book/list/list.component';

import { AddComponent } from './component/student/add/add.component';
import { ListComponent } from './component/student/list/list.component';
const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'add-student', component: AddComponent},
  {path: 'list-student', component: ListComponent},
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
