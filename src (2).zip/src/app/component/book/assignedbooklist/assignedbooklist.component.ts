import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignedbooklist',
  templateUrl: './assignedbooklist.component.html',
  styleUrls: ['./assignedbooklist.component.css']
})
export class AssignedbooklistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
