import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignedbooklistComponent } from './assignedbooklist.component';

describe('AssignedbooklistComponent', () => {
  let component: AssignedbooklistComponent;
  let fixture: ComponentFixture<AssignedbooklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignedbooklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedbooklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
