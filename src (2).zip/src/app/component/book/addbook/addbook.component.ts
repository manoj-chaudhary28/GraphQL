import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';
import { Router,ActivatedRoute } from '@angular/router';

const submitBook = gql`
mutation ($book:BookInput!){createBook(book:$book){bookName language author description}}`;

const fetchBook = gql`
mutation ($bookId:Int!)
{getBookById(bookId:$bookId)
{bookId bookName language author description}}
`;

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {

  model: any = {};
   
  constructor(private apollo:Apollo, private router: Router,private queryRoute: ActivatedRoute) { }
  ngOnInit() 
  {
    if(this.queryRoute.snapshot.params["id"])
    {
      var bookId=this.queryRoute.snapshot.params["id"];
      this.onGetById(bookId);
    }
  }

  onGetById(Id:string)
  {
    this.apollo.mutate({
      mutation: fetchBook,
      variables: {
        bookId:Id
    }
    }).subscribe(({ data }) => 
    {
        this.model.bookId=data.getBookById["bookId"];
        this.model.bookName=data.getBookById["bookName"];
        this.model.language=data.getBookById["language"];
        this.model.author=data.getBookById["author"];
        this.model.description=data.getBookById["description"];
       
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
  save(){

    this.apollo.mutate({
      mutation: submitBook,
      variables: {
        book:{
          bookId: this.model.bookId,
          bookName: this.model.bookName,
          language: this.model.language,
          author:this.model.author,
          description:this.model.description,
      }
    }
    }).subscribe(({ data }) => {
    
      this.router.navigate(['/list-book']);
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

}
