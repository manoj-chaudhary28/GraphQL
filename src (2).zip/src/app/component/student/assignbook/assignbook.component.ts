import { Component, OnInit } from '@angular/core';
import gql from 'graphql-tag';
import{Apollo} from 'apollo-angular';
import { Router,ActivatedRoute } from '@angular/router';

const fetchStudentBook = gql`
query bookandstudent{student{firstName,lastName,studentId},book{bookName,bookId}}
`;

const assignBookToStudent = gql`
mutation ($studentassignedbook:StudentAssignedBookInput!)
{assignBookToStudent(studentassignedbook:$studentassignedbook)
{bookId studentId assignedDate returnDate status}}
`;
 
const getAssignedBook = gql`
mutation ($assignedId:Int!)
{getAssignedById(assignedId:$assignedId)
{assignedId studentId bookId assignedDate returnDate status}}
`;

@Component({
  selector: 'app-assignbook',
  templateUrl: './assignbook.component.html',
  styleUrls: ['./assignbook.component.css']
})
export class AssignbookComponent implements OnInit {
   model: any = {};
  public studentBook:any;
   bookId="0";
   studentId ="0";
   assignDate=null;
   returnDate =null;
   status =null;
   assignedId="0";
  constructor(private apollo:Apollo,private router: Router,private queryRoute: ActivatedRoute) { }

  ngOnInit() 
  { 
    if(this.queryRoute.snapshot.params["id"])
   {
    var assignedId=this.queryRoute.snapshot.params["id"];
    this.onGetById(assignedId);
   }
   else
   {
    this.fetch()
   }
    
  }

  fetch()
  {
    this.apollo.query({
      query: fetchStudentBook,
      variables: {
        bookandstudent:{}
    }
    }).subscribe(({ data }) => {
      this.studentBook=data;
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
  onGetById(Id:string)
  {
    this.apollo.mutate({
      mutation: getAssignedBook,
      variables: {
        assignedId:Id
    }
    }).subscribe(({ data }) => {
      debugger;
       // this.studentId=data.getAssignedById["studentId"];
       // this.bookId=data.getAssignedById["bookId"];
        this.model.assignDate=data.getAssignedById["assignedDate"];
        this.model.returnDate=data.getAssignedById["returnDate"];
        this.model.status=data.getAssignedById["status"];
        this.model.assignedId=data.getAssignedById["assignedId"];
      //  this.studentBook.book=data.getAssignedById["book"];
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }
  save(){
    
    this.apollo.mutate({
      mutation: assignBookToStudent,
      variables: {
        studentassignedbook:{
          studentId: this.studentId,
          bookId: this.bookId,
          assignedDate:this.assignDate.day+"-"+this.assignDate.month+"-"+this.assignDate.year,
          returnDate:this.returnDate.day+"-"+this.returnDate.month+"-"+this.returnDate.year,
          status:this.status
      }
    }

    }).subscribe(({ data }) => {
      this.router.navigate(['/list-assigned-book']);
    }, (error) => {
      console.log('there was an error sending the query', error);
    });
  }

}
