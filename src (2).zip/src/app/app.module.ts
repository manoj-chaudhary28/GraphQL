import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { HttpClientModule } from '@angular/common/http';
import { ApolloModule, Apollo} from 'apollo-angular';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { HttpLinkModule, HttpLink } from 'apollo-angular-link-http';
import { AddComponent } from './component/student/add/add.component';
import { ListComponent } from './component/student/list/list.component';
import { NgForm, FormBuilder, FormsModule, FormGroup, Validators, FormControl } from '@angular/forms';
import { AddbookComponent } from './component/book/addbook/addbook.component';
import { ListbookComponent } from './component/book/listbook/listbook.component';
import { AssignbookComponent } from './component/student/assignbook/assignbook.component';
import { AssignedbooklistComponent } from './component/student/assignedbooklist/assignedbooklist.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddComponent,
    ListComponent,
    AddbookComponent,
    ListbookComponent,
    AssignbookComponent,
    AssignedbooklistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ApolloModule,
    HttpLinkModule,
     FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(
    apollo: Apollo,
    httpLink: HttpLink
  ) {
     apollo.create({
      link: httpLink.create({ uri: 'http://localhost:5000/api/GraphQL/Post'}),
      cache: new InMemoryCache()
    });
  }
 }
