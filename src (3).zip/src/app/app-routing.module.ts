import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
 import { AddbookComponent } from './component/book/addbook/addbook.component';
import { ListbookComponent } from './component/book/listbook/listbook.component';

import { AddComponent } from './component/student/add/add.component';
import { ListComponent } from './component/student/list/list.component';
import { AssignbookComponent } from './component/student/assignbook/assignbook.component';
import { AssignedbooklistComponent } from './component/student/assignedbooklist/assignedbooklist.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'add-student', component: AddComponent},
  {path: 'add-student/:id', component: AddComponent},
  {path: 'list-student', component: ListComponent},
  {path: 'add-book', component: AddbookComponent},
  {path: 'add-book/:id', component: AddbookComponent},
  {path: 'list-book', component: ListbookComponent},
  {path: 'assign-book-to-student', component: AssignbookComponent},
  {path: 'assign-book-to-student/:id', component: AssignbookComponent},
  {path: 'list-assigned-book', component: AssignedbooklistComponent},
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
