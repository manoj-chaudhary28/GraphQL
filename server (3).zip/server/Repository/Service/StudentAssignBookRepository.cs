
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GraphQL;
using Microsoft.EntityFrameworkCore;
using server.Contaxt;
using server.Models;
using server.Repository.IRepository;
using server.ViewModel;

namespace server.Repository.Service
{
    public class StudentAssignBookRepository : IStudentAssignBookRepository
    {
        private readonly GraphQLContext _db;

        public StudentAssignBookRepository(GraphQLContext db)
        {
            _db = db;
        }
        public async Task<AssignedBookViewModel> Get(int id)
        {
           var bookList=_db.Books.ToList();
           var studentList=_db.Students.ToList();

            
//            return _assignedBookList;
            StudentAssignedBook  studentAssignedBookObject=await _db.StudentAssignedBook.FirstOrDefaultAsync(p => p.AssignedId == id);
           AssignedBookViewModel assignedBookViewModel= new AssignedBookViewModel();
            if (studentAssignedBookObject !=null && studentAssignedBookObject.AssignedId > 0)
            {
                assignedBookViewModel.AssignedId=studentAssignedBookObject.AssignedId;
                assignedBookViewModel.StudentId=Convert.ToInt64(studentAssignedBookObject.StudentId);
                assignedBookViewModel.BookId=Convert.ToInt64(studentAssignedBookObject.BookId);
                assignedBookViewModel.AssignedDate=Convert.ToDateTime(studentAssignedBookObject.AssignedDate).ToString("yyyy-MM-dd");
                assignedBookViewModel.ReturnDate=Convert.ToDateTime(studentAssignedBookObject.ReturnDate).ToString("yyyy-MM-dd");
                assignedBookViewModel.Status=studentAssignedBookObject.Status;
            } 
          
            return assignedBookViewModel;
        }

        public List<AssignedBookViewModel> All()
        {
            var bookList=_db.Books.ToList();
            var studentList=_db.Students.ToList();

           List<StudentAssignedBook> _booklist= new  List<StudentAssignedBook>();
            _booklist= _db.StudentAssignedBook.ToList();

            List<AssignedBookViewModel> _assignedBookList= new  List<AssignedBookViewModel>();
            if(_booklist !=null && _booklist.Count > 0 )
            {
              foreach(var item in _booklist)   
              {
                  _assignedBookList.Add(new AssignedBookViewModel{
                    AssignedId=item.AssignedId,
                    StudentName=studentList.FirstOrDefault(s=>s.StudentId==Convert.ToInt64(item.StudentId)).FirstName,
                    BookName=bookList.FirstOrDefault(b=>b.BookId==Convert.ToInt64(item.BookId)).BookName,
                    AssignedDate=Convert.ToDateTime(item.AssignedDate).ToString("dd-MM-yyyy"),
                    ReturnDate=Convert.ToDateTime(item.ReturnDate).ToString("dd-MM-yyyy"),
                    Status=item.Status
                  });
              }
            }
            return _assignedBookList;
        }

        public async Task<StudentAssignedBook> Add(StudentAssignedBook book)
        {

         
 if(book.AssignedId > 0)
            {
                StudentAssignedBook booksObject=await _db.StudentAssignedBook.FirstOrDefaultAsync(p => p.AssignedId==book.AssignedId);
                book.CreateDate=booksObject.CreateDate;
                _db.Entry(booksObject).CurrentValues.SetValues(book);
                await _db.SaveChangesAsync();
            }
            else
            {
                  book.CreateDate=DateTime.UtcNow;
            await _db.StudentAssignedBook.AddAsync(book);
            await _db.SaveChangesAsync();
            }

           
            return book;
        }

         public StudentBookViewModel GetStudentBook()
        {
            StudentBookViewModel _viewModel= new StudentBookViewModel();
            _viewModel.Books=_db.Books.ToList();
             _viewModel.Students=_db.Students.ToList();
             return  _viewModel;
        }
        
    }
}
