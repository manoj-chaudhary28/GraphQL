 

using GraphQL.Types;
using server.Models;
namespace server.Fields
{
   public class StudentAssignedBookFields : ObjectGraphType<StudentAssignedBook>
    {
        public StudentAssignedBookFields()
        {
            Field(x => x.AssignedId,true);
            Field(x => x.BookId,true);
            Field(x => x.StudentId,true);
            Field(x => x.AssignedDate,true);
            Field(x => x.ReturnDate,true);
            Field(x => x.Status,true);
            
        }
    }
}
