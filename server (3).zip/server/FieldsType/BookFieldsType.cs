 
using GraphQL.Types;
 
namespace server.FieldsType
{
    public class BookFieldsType : InputObjectGraphType
    {
        public BookFieldsType()
        {
            Name="BookInput";
            Field<IntGraphType>("bookId");
            Field<StringGraphType>("bookName");
            Field<StringGraphType>("language");
            Field<StringGraphType>("author");
            Field<StringGraphType>("description");
             
        }
    }
}
